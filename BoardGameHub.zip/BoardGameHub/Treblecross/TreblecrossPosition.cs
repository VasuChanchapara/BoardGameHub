﻿namespace BoardGameHub;

public class TreblecrossPosition : IPosition
{
    public int Position { get; set; }

    public TreblecrossPosition(int position)
    {
        ArgumentNullException.ThrowIfNull(position);
        Position = position;
    }
}
