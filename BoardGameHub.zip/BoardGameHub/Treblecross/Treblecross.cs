﻿using Newtonsoft.Json;

namespace BoardGameHub.Games;

public class Treblecross : GameBase<TreblecrossBoard, TreblecrossPosition>
{
    public IGameRules GameRules;

    public Treblecross(TreblecrossBoard board, IGameRules gameRules) : base(board)
    {
        ArgumentNullException.ThrowIfNull(gameRules);
        GameRules = gameRules;
    }

    public override void Initialize()
    {
        currentPlayer = 1;
        UndoStack.Clear();
        RedoStack.Clear();
    }

    public override bool MakeMove(int playerId, IPosition position)
    {
        var tPosition = ((TreblecrossPosition)position).Position;
        if (!IsValidPlayerId(playerId))
        {
            throw new ArgumentException("Invalid player ID.");
        }

        if (!IsValidPosition(tPosition))
        {
            throw new ArgumentException("Invalid position.");
        }

        if (!GameRules.IsValidMove(Board, position))
        {
            return false;
        }

        char symbol = (playerId == 1) ? 'X' : 'O';
        Board.FillCell(tPosition, symbol);
        UndoStack.Push(new Move(playerId, new TreblecrossPosition(tPosition)));
        RedoStack.Clear();
        SwitchTurns();
        return true;
    }

    private void SwitchTurns()
    {
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    }

    public override bool IsGameOver()
    {
        return GameRules.IsGameOver(Board);
    }

    public override int GetWinner()
    {
        return GameRules.GetWinner(Board);
    }

    public override TreblecrossPosition GetMaxPosition()
    {
        return new TreblecrossPosition(Board.BoardSize - 1);
    }

    public override int GetCurrentPlayer()
    {
        return currentPlayer;
    }

    public override bool CanUndo()
    {
        return UndoStack.Count > 0;
    }

    public override bool UndoMove()
    {
        if (CanUndo())
        {
            var move = UndoStack.Pop();
            var position = ((TreblecrossPosition)move.Position).Position;
            Board.ResetCell(position);
            RedoStack.Push(move);
            SwitchTurns();
            return true;
        }
        return false;
    }

    public override bool CanRedo()
    {
        return RedoStack.Count > 0;
    }

    public override bool RedoMove()
    {
        var move = RedoStack.Peek();
        int position = ((TreblecrossPosition)move.Position).Position;
        var symbol = (move.PlayerId == 1) ? 'X' : 'O';
        Board.FillCell(position, symbol);
        SwitchTurns();
        RedoStack.Pop();
        UndoStack.Push(move);
        return true;
    }

    private bool IsValidPlayerId(int playerId)
    {
        return playerId == 1 || playerId == 2;
    }

    private bool IsValidPosition(int position)
    {
        return position >= 0 && position < Board.BoardSize;
    }
}
