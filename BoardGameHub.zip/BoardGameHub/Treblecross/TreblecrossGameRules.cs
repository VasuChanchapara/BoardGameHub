﻿namespace BoardGameHub;

public class TreblecrossGameRules : IGameRules
{
    public bool IsValidMove(IBoard board, IPosition position)
    {
        if (position is TreblecrossPosition treblecrossPosition)
        {
            return treblecrossPosition.Position >= 0
                && treblecrossPosition.Position < board.BoardSize
                && board.IsCellEmpty(treblecrossPosition.Position);
        }
        return false;
    }

    public bool IsGameOver(IBoard board)
    {
        // Check for horizontal wins
        for (int i = 0; i <= board.BoardSize - 3; i++)
        {
            if (board.Board[i] != ' ' &&
                board.Board[i] == board.Board[i + 1] &&
                board.Board[i + 1] == board.Board[i + 2])
            {
                return true;
            }
        }

        // Check for no more empty spaces (stalemate)
        for (int i = 0; i < board.BoardSize; i++)
        {
            if (board.Board[i] == ' ')
            {
                return false;
            }
        }
        return true;
    }

    public int GetWinner(IBoard board)
    {
        if (IsGameOver(board))
        {
            // Check for horizontal wins
            for (int i = 0; i <= board.BoardSize - 3; i++)
            {
                if (board.Board[i] != ' ' &&
                    board.Board[i] == board.Board[i + 1] &&
                    board.Board[i + 1] == board.Board[i + 2])
                {
                    return board.Board[i] == 'X' ? 1 : 2;
                }
            }
        }

        return -1; // No winner yet
    }
}


