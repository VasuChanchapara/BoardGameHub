﻿using System.Text;

namespace BoardGameHub;

public class TreblecrossBoard : IBoard
{
    private char[] board;

    public char[] Board
    {
        get => board;
        set => board = value;
    }

    public int BoardSize => board.Length;

    public TreblecrossBoard(int boardSize)
    {
        if (boardSize < 3)
        {
            throw new InvalidOperationException("BoardSize shoule at least be 3.");
        }

        board = new char[boardSize];
        for (int i = 0; i < boardSize; i++)
        {
            board[i] = ' ';
        }
    }

    public void FillCell(int position, char symbol)
    {
        if (position < 0 || position >= BoardSize)
        {
            throw new ArgumentOutOfRangeException(nameof(position), "Position is out of range.");
        }

        if (board[position] != ' ')
        {
            throw new InvalidOperationException("The cell is already filled.");
        }

        board[position] = symbol;
    }

    public void ResetCell(int position)
    {
        if (position < 0 || position >= BoardSize)
        {
            throw new ArgumentOutOfRangeException(nameof(position), "Invalid Position");
        }

        board[position] = ' ';
    }

    public bool IsCellEmpty(int position)
    {
        if (position < 0 || position >= BoardSize)
        {
            throw new ArgumentOutOfRangeException(nameof(position), "Position is out of range.");
        }

        return board[position] == ' ';
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();

        // Top border (optional)
        sb.AppendLine(new string('-', BoardSize * 4));  // Uncomment if you want a top border

        // Cells with values and borders
        for (int i = 0; i < BoardSize - 1; i++)  // Loop till second-last cell
        {
            sb.AppendFormat(" {0} |", board[i]);
        }

        // Handle the last cell separately for proper formatting
        sb.AppendFormat(" {0} ", board[BoardSize - 1]);

        sb.AppendLine();  // New line after cells

        // Bottom border (optional)
        sb.AppendLine(new string('-', BoardSize * 4));  // Uncomment if you want a bottom border

        return sb.ToString();
    }






    public int[] GetEmptyCells()
    {
        List<int> emptyCells = [];
        for (int i = 0; i < BoardSize; i++)
        {
            if (board[i] == ' ')
            {
                emptyCells.Add(i);
            }
        }
        return emptyCells.ToArray();
    }
}
