﻿using BoardGameHub.Games;

namespace BoardGameHub;

public class TreblecrossAI : ComputerPlayer
{
    public override IPosition CreateMove(IGame game, string input)
    {
        // Analyze game state (board layout, opponent moves)
        if (game is not Treblecross treblecrossGame)
        {
            throw new ArgumentException("Invalid game type. Expected Treblecross.");
        }

        int[] emptyCells = treblecrossGame.GetEmptyCells();

        // Simple evaluation (choose a random available move)
        Random random = new();
        int chosenMove = emptyCells[random.Next(emptyCells.Length)];

        return new TreblecrossPosition(chosenMove);
    }
}

