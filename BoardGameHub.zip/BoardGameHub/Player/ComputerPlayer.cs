﻿namespace BoardGameHub;

public abstract class ComputerPlayer : IPlayer
{
    public abstract IPosition CreateMove(IGame game, string input);

    public string GetPlayerType() => "Computer";
}

