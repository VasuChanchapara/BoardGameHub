﻿namespace BoardGameHub;

public class HumanPlayer : IPlayer
{
    private readonly IPositionParser positionParser;

    public HumanPlayer(IPositionParser positionParser)
    {
        ArgumentNullException.ThrowIfNull(positionParser);

        this.positionParser = positionParser;
    }

    public IPosition CreateMove(IGame game, string input)
    {
        do
        {
            try
            {
                return ParsePosition(game, input);
            }
            catch (InvalidUserInputException ex)
            {
                Console.WriteLine("Invalid move: {0}", ex.Message);
            }
        } while (string.IsNullOrEmpty(input));

        throw new InvalidUserInputException("");
    }

    private IPosition ParsePosition(IGame game, string input)
    {
        return positionParser.ParsePosition(game, input);
    }

    public string GetPlayerType()
    {
        return "Human";
    }
}

