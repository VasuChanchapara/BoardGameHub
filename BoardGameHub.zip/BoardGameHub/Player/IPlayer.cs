﻿namespace BoardGameHub;

public interface IPlayer
{
    IPosition CreateMove(IGame game, string input);

    string GetPlayerType();
}
    