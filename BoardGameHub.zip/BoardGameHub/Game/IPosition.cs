﻿namespace BoardGameHub;

public interface IPosition
{

}
