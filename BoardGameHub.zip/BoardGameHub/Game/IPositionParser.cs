﻿using BoardGameHub.Games;

namespace BoardGameHub;

public interface IPositionParser
{
    IPosition ParsePosition(IGame game, string userInput);
}

public class TreblecrossPositionParser : IPositionParser
{
    public IPosition ParsePosition(IGame game, string userInput)
    {
        ArgumentNullException.ThrowIfNull(game);
        ArgumentNullException.ThrowIfNull(userInput);

        if (int.TryParse(userInput, out int position))
        {
            // Validate position within board bounds (optional)
            int maxPosition = ((TreblecrossPosition)game.GetMaxPosition()).Position;
            if (position < 0 || position > maxPosition)
            {
                throw new InvalidUserInputException($"Please enter a number between 0 and {maxPosition}");
            }

            return new TreblecrossPosition(position);
        }

        throw new InvalidUserInputException("Invalid input, make a valid move");
    }
}
