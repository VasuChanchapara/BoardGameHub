﻿namespace BoardGameHub;

public interface IMoveFormatHintProvider
{
    string GetMoveFormatHint(IGame game);
}

public class TreblecrossMoveFormatHintProvider : IMoveFormatHintProvider
{
    public string GetMoveFormatHint(IGame game)
    {
        TreblecrossPosition maxPosition = (TreblecrossPosition)game.GetMaxPosition();
        return $"position number (0-{maxPosition.Position})";
    }
}
