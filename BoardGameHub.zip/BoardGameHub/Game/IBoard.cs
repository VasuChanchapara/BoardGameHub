﻿namespace BoardGameHub;

public interface IBoard
{
    char[] Board { get; }

    int BoardSize { get; }

    bool IsCellEmpty(int position);

    void FillCell(int position, char symbol);

    void ResetCell(int position);

    int[] GetEmptyCells();
}
