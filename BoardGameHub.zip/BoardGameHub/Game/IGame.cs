﻿namespace BoardGameHub;

public interface IGame
{
    void Initialize();

    bool MakeMove(int playerId, IPosition position);

    bool CanUndo();

    bool UndoMove();

    bool CanRedo();

    bool RedoMove();

    int GetCurrentPlayer();

    bool IsGameOver();

    int GetWinner();

    string GetBoardState();

    IPosition GetMaxPosition();

    string GetMoveFormatHint();

    bool SaveGame(string player1Type, string player2Type, string fileName);

    (bool, string, string) LoadGame(string fileName);
}