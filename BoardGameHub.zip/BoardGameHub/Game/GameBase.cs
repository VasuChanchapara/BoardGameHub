﻿using System.Runtime.InteropServices.Marshalling;
using BoardGameHub.Games;
using Newtonsoft.Json;

namespace BoardGameHub;

public abstract class GameBase<TBoard, TPosition>
    : IGame where TBoard : IBoard where TPosition : IPosition
{
    protected TBoard Board;

    protected int currentPlayer;

    protected readonly Stack<Move> UndoStack;

    protected readonly Stack<Move> RedoStack;

    public GameBase(TBoard board)
    {
        ArgumentNullException.ThrowIfNull(board);

        Board = board;
        UndoStack = new Stack<Move>();
        RedoStack = new Stack<Move>();
    }

    public abstract void Initialize();

    public abstract bool MakeMove(int playerId, IPosition position);

    public abstract bool IsGameOver();

    public abstract int GetWinner();

    public virtual string GetBoardState()
    {
        return Board.ToString() ?? string.Empty;
    }

    public virtual int[] GetEmptyCells()
    {
        return Board.GetEmptyCells();
    }

    public abstract IPosition GetMaxPosition();

    public abstract int GetCurrentPlayer();

    public abstract bool CanUndo();

    public abstract bool UndoMove();

    public abstract bool CanRedo();

    public abstract bool RedoMove();

    public virtual string GetMoveFormatHint()
    {
        IMoveFormatHintProvider moveFormatHintProvider;
        if (this is Treblecross)
        {
            moveFormatHintProvider = new TreblecrossMoveFormatHintProvider();
        }
        else
        {
            // If no matching provider is found, throw an exception
            throw new NotSupportedException($"Move format hint provider not available for game type: {GetType().Name}");
        }

        return moveFormatHintProvider.GetMoveFormatHint(this);
    }

    public virtual bool SaveGame(string player1Type, string player2Type, string fileName)
    {
        if (string.IsNullOrEmpty(player1Type) || string.IsNullOrEmpty(player2Type))
        {
            Console.WriteLine($"Error saving game: Invalid Player Type");
            return false;
        }
        try
        {
            var gameState = new GameState<TBoard>(player1Type, player2Type, currentPlayer, Board);
            string jsonData = JsonConvert.SerializeObject(gameState);
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);

            File.WriteAllText(filePath, jsonData);

            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error saving game: {ex.Message}");
            return false;
        }
    }

    public virtual (bool, string, string) LoadGame(string fileName)
    {
        try
        {
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);

            if (!File.Exists(filePath))
                return (false, string.Empty, string.Empty);

            string jsonData = File.ReadAllText(filePath);

            GameState<TBoard>? gameState = JsonConvert.DeserializeObject<GameState<TBoard>>(jsonData);

            if (gameState != null)
            {
                currentPlayer = gameState.CurrentPlayer ?? 0;
                if (gameState.Board is null)
                {
                    return (false, string.Empty, string.Empty);
                }
                Board = gameState.Board;
                return (true, gameState.Player1Type, gameState.Player2Type);
            }
            else
            {
                return (false, string.Empty, string.Empty);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading game: {ex.Message}");
            return (false, string.Empty, string.Empty);
        }
    }
}
