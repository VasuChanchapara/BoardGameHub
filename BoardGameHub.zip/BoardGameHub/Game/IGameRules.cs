﻿namespace BoardGameHub;

public interface IGameRules
{
    bool IsValidMove(IBoard board, IPosition position);

    bool IsGameOver(IBoard board);

    int GetWinner(IBoard board);
}
