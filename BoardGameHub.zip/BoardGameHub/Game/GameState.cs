﻿using Newtonsoft.Json;

namespace BoardGameHub;

public record GameState<TBoard> where TBoard : IBoard
{
    public string Player1Type { get; init; }

    public string Player2Type { get; init; }

    public int? CurrentPlayer { get; init; }

    public TBoard? Board { get; init; }

    public GameState(string player1Type, string player2Type, int? currentPlayer = 1, TBoard? board = default)
    {
        Player1Type = player1Type;
        Player2Type = player2Type;
        CurrentPlayer = currentPlayer;
        Board = board;
    }

}
