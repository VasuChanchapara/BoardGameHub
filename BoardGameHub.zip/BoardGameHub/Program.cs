﻿using BoardGameHub.Games;

namespace BoardGameHub;

public class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Board Game Hub!");

        IGame game; 

        Console.WriteLine("1. Start a new Treblecross game");
        Console.WriteLine("2. Load Treblecross game");

        string? gameInput = Console.ReadLine();

        switch (gameInput)
        {
            case "1":
                Console.WriteLine("Enter the board size:");
                string? boardSizeInput = Console.ReadLine();
                if (!int.TryParse(boardSizeInput, out int boardSize) || boardSize < 3)
                {
                    Console.WriteLine("Invalid board size. Exiting...");
                    return;
                }
                game = new Treblecross(new TreblecrossBoard(boardSize), new TreblecrossGameRules());
                InitializeNewGame(game);
                DeclareWinner(game);
                Console.WriteLine("Game over!");
                break;
            case "2":
                game = new Treblecross(new TreblecrossBoard(3), new TreblecrossGameRules());
                LoadSavedGame(game);
                DeclareWinner(game);
                Console.WriteLine("Game over!");
                break;
            default:
                Console.WriteLine("Invalid Option");
                return;
        }

    }


    private static void InitializeNewGame(IGame game)
    {
        IPositionParser positionParser = new TreblecrossPositionParser();
        game.Initialize();
        IPlayer player1 = new HumanPlayer(positionParser);
        IPlayer player2;

        try
        {
            string opponentChoice;
            bool isComputerOpponent;

            do
            {
                Console.WriteLine("Select opponent:");
                Console.WriteLine("1. Human");
                Console.WriteLine("2. Computer");

                opponentChoice = Console.ReadLine() ?? string.Empty;
            } while (opponentChoice != "1" && opponentChoice != "2");

            isComputerOpponent = opponentChoice == "2";
            player2 = isComputerOpponent ? new TreblecrossAI() : new HumanPlayer(positionParser);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("Error during game setup: {0}", ex.Message);
            return;
        }

        PlayGame(game, player1, player2);

    }

    private static void LoadSavedGame(IGame game)
    {
        var (loaded, player1Type, player2Type) = game.LoadGame("saved_game.json");
        if (!loaded)
        {
            Console.WriteLine("Failed to load game. no saved Game found,  Starting new game with 7 board size");
            InitializeNewGame(game);
        }
        else
        {
            Console.WriteLine("Game loaded successfuly");
            DisplayBoard(game);
            IPositionParser positionParser = new TreblecrossPositionParser();
            IPlayer player1 = new HumanPlayer(positionParser);
            IPlayer player2 = player2Type == "Human" ? new HumanPlayer(positionParser) : new TreblecrossAI();
            PlayGame(game, player1, player2);
        }
    }


    private static void PlayGame(IGame game, IPlayer player1, IPlayer player2)
    {
        Console.WriteLine("Options are  'undo', 'redo', 'save', or 'exit'");

        // Main game loop
        while (!game.IsGameOver())
        {
            // Current player's turn
            int playerId = game.GetCurrentPlayer();
            IPlayer currentPlayer = (playerId == 1) ? player1 : player2;

            string? input;
            // Get move from player
            try
            {
                if (currentPlayer.GetPlayerType() == "Human")
                {
                    Console.WriteLine("[Player {0}] Enter your move (format: {1}):", playerId, game.GetMoveFormatHint());

                    input = Console.ReadLine() ?? string.Empty;

                    if (input.Equals("undo", StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (game.CanUndo())
                        {
                            game.UndoMove();
                            playerId = game.GetCurrentPlayer();
                            if (player2.GetPlayerType() == "Computer" && playerId == 2)
                            {
                                Console.WriteLine("Computer Move undone");
                                game.UndoMove();
                                Console.WriteLine("[Player 1] Move undone", playerId);
                            }
                            else
                            {
                                Console.WriteLine("[Player {0}] Move undone", playerId);
                            }
                            DisplayBoard(game);
                        }
                        else
                        {
                            Console.WriteLine("No moves to undo.");
                        }
                        continue;
                    }
                    else if (input.Equals("redo", StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (game.CanRedo())
                        {
                            game.RedoMove();
                            playerId = game.GetCurrentPlayer();
                            if (player2.GetPlayerType() == "Computer" && playerId == 2)
                            {
                                Console.WriteLine("[Player 1] Move redone", playerId);
                                game.RedoMove();
                                Console.WriteLine("Computer Move redone");
                            }
                            else
                            {
                                Console.WriteLine("[Player {0}] Move redone", playerId);
                            }
                            DisplayBoard(game);
                        }
                        else
                        {
                            Console.WriteLine("No moves to redo.");
                        }
                        continue;
                    }
                    else if (input.Equals("save", StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (game.SaveGame(player1.GetPlayerType(), player2.GetPlayerType(), "saved_game.json"))
                        {
                            Console.WriteLine("Game Saved.");
                        }
                        continue;
                    }
                    else if (input.Equals("exit", StringComparison.CurrentCultureIgnoreCase))
                    {
                        break;
                    }
                 


                    IPosition move = currentPlayer.CreateMove(game, input);

                    // Validate and make the move
                    if (game.MakeMove(playerId, move))
                    {
                        DisplayBoard(game);
                    }
                    else
                    {
                        Console.WriteLine("Invalid move. Please try again.");
                    }
                }
                else
                {
                    IPosition move = currentPlayer.CreateMove(game, "");
                    if (game.MakeMove(playerId, move))
                    {
                        Console.WriteLine("Computer Played: {0}", ((TreblecrossPosition)move).Position);
                        DisplayBoard(game);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("Error during player move: {0}", ex.Message);
                // Handle the error (e.g., prompt for a new move, end the game)
            }
        }

    }

    private static void DisplayBoard(IGame game)
    {
        Console.WriteLine(game.GetBoardState());
    }


    private static void DeclareWinner(IGame game)
    {
        int winner = game.GetWinner();
        if (winner > 0)
        {
            Console.WriteLine("Player " + winner + " wins!");
        }
        else
        {
            Console.WriteLine("Stalemate! No winner.");
        }
    }
}
